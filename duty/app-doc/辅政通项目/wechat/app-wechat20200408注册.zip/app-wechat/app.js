//app.js
App({
  globalData: {
    userInfo: null,
    latitude:'',
    longitude:'',
    userId:'',
    mobile:'',
    avatarUrl:'',  //获取用户头像
    username:'',  //角色
    isDuty:'', // 1 上岗 2 离岗
    authority:'', //权限
    whitelist:{}, //白名单
    allChoeese: {},
    levels: {},
    level: 3,
    globalChoose:[], //全局对象存放联系人数组列表
    allDate:[], //新建信息主页数据['a','b'...]
    before: null,
    login: null,
  },
  onLaunch: function () {
    // 查看是否授权
  },
  onload:function(){
    wx.onAppRoute(function (res) {
      console.log({res})
    })
  },
 
  getLocation:function(){
    let me = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        me.globalData.latitude = res.latitude;
        me.globalData.longitude = res.longitude;
      }
    })
  },
  // 数组去重
  unique: function (arr) {
    return Array.from(new Set(arr))
  },
  location: () => {
    return new Promise((resolve, reject) => {
      wx.getLocation({
        type: 'wgs84',
        success: (res) => { resolve(res) },
        fail: (res) => { reject(res) }
      })
    })
  }
})