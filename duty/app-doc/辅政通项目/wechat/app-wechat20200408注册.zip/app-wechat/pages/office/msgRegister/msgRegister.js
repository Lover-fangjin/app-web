const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
import Notify from 'vant-weapp/notify/notify';
Page({
  /**
   * 页面的初始数据
   */
  data: {
    names:'',
    tells:'',
    numbers:'',
    detile:'',
    todayTotal:'',
    weizhi:'' //登记位置
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let me = this;
    me.normalTotal();
  },
  // 位置
  chooseMap: function () {
    let that = this;
    wx.chooseLocation({
      success(res) {
        // console.log(res)
        that.setData({
          // hasLocation: true,
          // location: formatLocation(res.longitude, res.latitude),
          weizhi: res.address
        })
      },
      fail: function () {
        wx.getSetting({
          success: function (res) {
            var statu = res.authSetting;
            if (!statu['scope.userLocation']) {
              wx.showModal({
                title: '是否授权当前位置',
                content: '需要获取您的地理位置，请确认授权，否则地图功能将无法使用',
                success: function (tip) {
                  if (tip.confirm) {
                    wx.openSetting({
                      success: function (data) {
                        if (data.authSetting["scope.userLocation"] === true) {
                          wx.showToast({
                            title: '授权成功',
                            icon: 'success',
                            duration: 1000
                          })
                          //授权成功之后，再调用chooseLocation选择地方
                          wx.chooseLocation({
                            success: function (res) {
                              obj.setData({
                                addr: res.address
                              })
                            },
                          })
                        } else {
                          wx.showToast({
                            title: '授权失败',
                            icon: 'success',
                            duration: 1000
                          })
                        }
                      }
                    })
                  }
                }
              })
            }
          },
          fail: function (res) {
            wx.showToast({
              title: '调用授权窗口失败',
              icon: 'success',
              duration: 1000
            })
          }
        })
      }
    })
  },
  // 基础信息跳转页面
  basicList:function(){
    // msgRegisterTable
    wx.navigateTo({
      url: './msgRegisterTable/msgRegisterTable'
    })
  },
  // 当前事件数量 事件类型
  normalTotal: function () {
    let me = this;
    let params = {
      'userId': app.globalData.userId
    }
    api.getnormalTotal(params, (res) => {
      me.setData({
        todayTotal: res.result.total
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
   // 提交
  formSubmit: function(e) {
    var _this = this;
    let normalReport = {};
    normalReport = e.detail.value;
    console.log(normalReport)
    if (normalReport.name == ''){
      Notify({ type: 'warning', 'message': '姓名不能为空', duration: 1500 });
    } else if (normalReport.tel == ''){
      Notify({ type: 'warning', 'message': '联系电话不能为空', duration: 1500 });
    } else if (normalReport.cause == '') {
      Notify({ type: 'warning', 'message': '来访事由不能为空', duration: 1500 });
    } else if (normalReport.location == ''){
      Notify({ type: 'warning', 'message': '登记位置不能为空', duration: 1500 });
    }else{
      normalReport['userId'] = app.globalData.userId
      api.getNormalReport(
        normalReport,
        function (res) {
          var _data = res.result;
          console.log(res)
          wx.showModal({
            title: '提示',
            content: "登记成功",
            success: function (res) {
              _this.setData({
                names: '',
                tells: '',
                numbers: '',
                detile: ''
              })
              if (res.confirm) {
                var pages = getCurrentPages(); //当前页面
                var beforePage = pages[pages.length - 2]; //前一页
                wx.navigateBack({
                  success: function () {
                    beforePage.onLoad(); // 执行前一个页面的onLoad方法
                  }
                });
              } else if (res.cancel) {
              }
            }
          })
          //   wx.hideLoading();
        },
        function () {
          _this.setData({ listArry: [] });
          // wx.hideLoading();
        }
      )
    }
  },

})