// pages/office/record/recordInfo/recordInfo.js
const app = getApp()
let util = require('../../../../../utils/util.js');
let api = require('../../../../../utils/api.method.js');
let xapp = require('../../../../../utils/request.url.js');
Page({
  data: {
    dataInfo: '',
    infoId: '',
    record: ''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let me = this, id = options['id'];
    if (id) {
      me.setData({
        infoId: options['id']
      })
    }
    me.eventListInfo();
  },
  eventListInfo: function () {
    let me = this;
    let params = {
      'reportId': this.data.infoId,
    }
    api.getNormalQueryById(params, (res) => {
      let dataInfo = res.result;
      let me = this;
      console.log('dataInfo', res)
      me.setData({
        dataInfo: dataInfo,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
})