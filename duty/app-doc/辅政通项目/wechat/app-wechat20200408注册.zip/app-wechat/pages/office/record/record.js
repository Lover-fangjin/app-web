//获取应用实例
const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
let xapp = require('../../../utils/request.url.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    zdNameArray: ['', '礼贤镇农建科', '恒信建业资产管理有限公司', '清源街道社会化', '市政养护队', '西红门城管', '西红门综治'],
    // eventTypeArray: ['', '火灾', '袭警', '闯岗', '盗窃', '发热'],
    eventTypeArray: [],
    eventClassArray:[],//事件类别
    healthCodeArray: ['医学观察','居家观察','未见异常'],
    healthCodeChoose: '请选择',    
    headIndex:'0',
    zdIndex: 1,
    typeClassIndex: 0,
    typeIndex: '0' ,
    customItem: [],
    detailed: '请选择', //居住地
    suodaoValue: '请选择',//所到地
    weizhi:'请选择',//位置
    radio: '1',
    form_data:'',
    addr: '',
    names:'',
    tells:"",
    numbers:"",
    temperature:'',
    detile:'',
    heatIsshow:false,
    fileList: [],
    imgIdList: [],
    pid:'-1',
    tid:'-1',
    cid:'-1'
  },
  onLoad: function (options) {
    let me = this;
    app.getLocation();
    me.eventClassList(me.data.pid);
  },
  //事件类别
  eventClassList: function (pid) {
    let me = this;
    let params = {
      'pid': pid
    }
    api.getTodayTotal(params, (res) => {
      let tylelist = [{'id':-1, 'name':'请选择事件类型'}]
      tylelist = tylelist.concat(res.result.dicts);
      me.setData({
        eventClassArray: tylelist,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  
  // 健康码状态
  healthType: function (e) {
    let me = this;
    console.log('eee', e.detail.value)
    this.setData({
      headIndex: e.detail.value
    })
  },
  // 上传
  afterRead(event) {
    const { file } = event.detail;
    let me = this;
    // 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
    wx.uploadFile({
      // url: 'http://192.168.10.81:8080/upload/singlefile', 
      url: `${xapp.url}/upload/singlefile`,
      filePath: file.path,
      name: 'file',
      formData: { user: 'test' },
      success(res) {
        // 上传完成需要更新 fileList
        const { fileList = [] } = me.data, { imgIdList = [] } = me.data;
        let imgData = JSON.parse(res.data).result
          , imgUrl = `${xapp.url}${imgData.filePath}`
          , imgId = imgData.attachmentId;
        // console.log('imgData.filePath', imgData.filePath)
        fileList.push({ ...file, url: imgUrl });
        me.data.imgIdList.push(imgId)
        me.setData({ fileList, imgId });
      }
    });
  },
  // 详情跳转
  recordInfo: function (){
    // wx.navigateTo({
      // url: "./recordInfo/recordInfo",
    // })
  },
 
  //事件类别
  eventClass: function(e) {
    let me = this;
    this.setData({
      typeClassIndex: e.detail.value,
    })
    let id = this.data.eventClassArray[e.detail.value].id;
    if(id == -1) {
      // 提示
      me.setData({
        eventTypeArray: [],
      })
      return;
    }
    me.setData({
      cid: id
    })
    let params = {
      'pid': id
    }
    if (id == '6') {
      me.setData({
        heatIsshow: true
      })
    } else {
      me.setData({
        heatIsshow: false
      })
    }
    api.getTodayTotal(params, (res) => {
      let typelist = res.result.dicts;
      console.log('typelist ===>', typelist)
      me.setData({
        eventTypeArray: typelist,
        tid: typelist[0].id
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  // 事件类型
  eventType: function (e) {
    let me = this;
    this.setData({
      typeIndex: e.detail.value,
    })
    let id = this.data.eventTypeArray[e.detail.value].id;
    if (id == -1) {
      // 提示
      me.setData({
        eventTypeArray: [],
        tid: -1
      })
      return;
    }
    this.setData({
      tid: id
    })
    console.log('事件类型==>', me.data.tid)
  }, 
  //省市联动 居住地
  bindRegionChange: function (e) {
    var that = this
    console.log('picker发送选择改变，携带值为', e.detail)
    this.setData({
      detailed: e.detail.value[0] + "" + e.detail.value[1] + "" + e.detail.value[2], //拼的字符串传后台
      region: e.detail.value//下拉框选中的值
    })
  },
  //省市联动 所在地
  bindRegionChanges: function (e) {
    var that = this    
    this.setData({
      //拼的字符串传后台
      suodaoValue: e.detail.value[0] + "" + e.detail.value[1] + "" + e.detail.value[2],
      //下拉框选中的值
      region: e.detail.value
    })
    console.log(e.detail.value)
  },
  // 位置
  // weizhichange:function(e){
  //   var that = this  
  //   that.setData({
  //     clas: ''
  //   })　　　//下拉框所选择的值
  //   // console.log('picker发送选择改变，携带值为', e.detail)
  //   this.setData({
  //     //拼的字符串传后台
  //     weizhi: e.detail.value[0] + "" + e.detail.value[1] + "" + e.detail.value[2],
  //     //下拉框选中的值
  //     region: e.detail.value
  //   })
  // },
 
  // 地址选择
  chooseMap: function () {
    let that = this;
    wx.chooseLocation({
      success(res) {
        // console.log(res)
        that.setData({
          // hasLocation: true,
          // location: formatLocation(res.longitude, res.latitude),
          weizhi: res.address
        })
      },
      fail: function () {
        wx.getSetting({
          success: function (res) {
            var statu = res.authSetting;
            if (!statu['scope.userLocation']) {
              wx.showModal({
                title: '是否授权当前位置',
                content: '需要获取您的地理位置，请确认授权，否则地图功能将无法使用',
                success: function (tip) {
                  if (tip.confirm) {
                    wx.openSetting({
                      success: function (data) {
                        if (data.authSetting["scope.userLocation"] === true) {
                          wx.showToast({
                            title: '授权成功',
                            icon: 'success',
                            duration: 1000
                          })
                          //授权成功之后，再调用chooseLocation选择地方
                          wx.chooseLocation({
                            success: function (res) {
                              obj.setData({
                                addr: res.address
                              })
                            },
                          })
                        } else {
                          wx.showToast({
                            title: '授权失败',
                            icon: 'success',
                            duration: 1000
                          })
                        }
                      }
                    })
                  }
                }
              })
            }
          },
          fail: function (res) {
            wx.showToast({
              title: '调用授权窗口失败',
              icon: 'success',
              duration: 1000
            })
          }
        })
      }
    })
  },
  // 出入记录单选框
  onChange(event) {
    this.setData({
      radio: event.detail
    });
  },
  // 提交
  formSubmit: function (e) {
    var _this = this;
    let eventdata = {};
    eventdata = e.detail.value;
    console.log('eventdata===>', eventdata)
    let remarks = util.filterEmoji(e.detail.value.remarks)
    eventdata['userId'] = app.globalData.userId;
    eventdata['address'] = this.data.detailed;
    eventdata['arrival'] = this.data.suodaoValue;
    eventdata['record'] = this.data.radio;
    eventdata['ext2'] = app.globalData.longitude; //经度
    eventdata['ext3'] = app.globalData.latitude; //纬度
    eventdata['remarks'] = remarks;
    eventdata['eventTypeId'] = _this.data.tid;
    eventdata['eventClassId'] = _this.data.cid;
        // me.statisticsCount();
    // console.log('eventdata', eventdata)
    let reportData = {
      'eventReport': eventdata,
      'imageIds': _this.data.imgIdList,
      'userId': app.globalData.userId
    }
    api.reports(
      reportData,
      function (res) {
        var _data = res.result;
        // console.log(res)
        wx.showModal({
          title: '提示',
          content: "上报成功",
          success: function (res) {
            _this.setData({
              addr: '',
              names: '',
              tells: "",
              numbers: "",
              temperature: '',
              address: '',
              detile: ''
            })
            if (res.confirm) {
              var pages = getCurrentPages(); //当前页面
              var beforePage = pages[pages.length - 2]; //前一页
              wx.navigateBack({
                success: function () {
                  beforePage.onLoad(); // 执行前一个页面的onLoad方法
                }
              });
            } else if (res.cancel) {
              _this.setData({
                submitDisable: false
              });
              // console.log('用户点击关闭')
            }
          }
        })
        //   wx.hideLoading();
      },
      function () {
        _this.setData({ listArry: [] });
        // wx.hideLoading();
      }
    )
  },
})