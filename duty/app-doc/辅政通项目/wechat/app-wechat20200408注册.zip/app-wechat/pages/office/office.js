//index.js
//获取应用实例
const app = getApp()
let util = require('../../utils/util.js');
let api = require('../../utils/api.method.js');
Page({
  data: {
    latitude:'', //纬度初始化
    longitude:'', //经度初始化
    disabled: true,
    onDuty:false, //上岗
    leaveDuty:false,  //离岗
    elseduty:false , //上报
    statisticsVisible:false ,// 统计
    tjShow:true, //根据不同角色 控制统计按钮的显示与隐藏
    c_authority:'',
    //权限字段：
    // 1 超级管理员  
    // 2 通过系统注册的用户
    // 81 应急大队指挥长
    // 82 应急大队教导员
    // 83 应急大队顾问
    // 84 中队长
    // 85 队员
    appList: [ 
      {
        "imgSrc":'/images/kaoqin.png',
        'label':'考勤打卡',
        "authority": ['1', '81', '82', '83', '84', '85'], 
        "url":'./checkIn/checkIn',
        "visible": true
      },
      {
        "imgSrc":'/images/shijian.png',
        "url":'./msgRegister/msgRegister',
        'label':'信息登记',
        "authority": ['1', '84','85'], 
        "visible": true
      },
      {
        "imgSrc":'/images/shijian.png',
        'label':'事件记录',
        "authority": ['1', '84', '85'], 
        "url": './record/record',
        "visible": true
      },
      {
        "imgSrc":'/images/liebiao.png',
        'label':'事件列表',
        "authority": ['1', '81', '82', '83', '84', '85'], 
        "url": './eventList/eventList',
        "visible": true
      },
      {
        "imgSrc": '/images/tongzhi.png',
        'label': '信息通知',
        "authority": ['1', '81', '82', '83', '84', '85'],
        "url": './smsNotice/smsNotice',
        "visible": true
      },
      {
        "imgSrc": '/images/tongxunlu.png',
        'label': '通讯录',
        "authority": ['1', '81', '82', '83', '84', '85'],
        "url": './addressBook/addressBook',
        "visible": true
      }
      // {
      //   "imgSrc":'/images/renwu.png',
      //   'label': '我的任务',
      //   "authority": ['1'], 
      //   // "authority": ['1', '84','85'], 
      //   "url": '',
      //   "visible": true
      // },
      // {
      //   "imgSrc":'/images/qingjia.png',
      //   'label': '请假',
      //   "authority": ['1'], 
      //   // "authority": ['1', '81', '82', '83', '84', '85'], 
      //   "url": '',
      //   "visible": true
      // },
      // {
      //   "imgSrc":'/images/tongxun.png',
      //   'label': '通讯录',
      //   "authority": ['1'], 
      //   // "authority": ['1', '81', '82', '83', '84', '85'], 
      //   "url": '',
      //   "visible": true
      // }
    ],
    nowDate: '',
    cdcs:'0',
    cqbc:'0',
    cqts:'0',
    ztcs:'0'
  },
  // 设置按钮状态
  btnDisiable:function(){
    this.setData({
      disabled: !this.data.disabled
    })
  },
  onLoad: function () {
    let me = this;
    me.date(); //当前时间
    app.getLocation();// 进页面自动获取当前位置
    me.statisticsCount(); // 统计接口
    if (app.globalData.latitude != " " && app.globalData.longitude != " "){
      me.btnDisiable()
    }
    wx.hideHomeButton() //取消左上角返回首页方法
  },
  onShow: function (){
    if (app.globalData.authority) {
      this.formatAuthority();
    }
  },

  // 获取当前时间
  date:function(){
    let me = this;
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    if (month < 10) {
      month = "0" + month;
    }
    if (day < 10) {
      day = "0" + day;
    }
    var nowDates = year + "-" + month + "-" + day;
    
    this.setData({
      nowDate: nowDates
    })
    console.log(nowDates)
  },
  //业务统计
  statisticsCount: function () {
    let me = this;
    let params = {
      'userId': app.globalData.userId,
      'month': me.data.nowDate,
    }
    api.getStatisticsCount(params, (res) => {
      console.log(res.result)
      me.setData({
        cdcs: res.result.cdcs,
        cqbc: res.result.cqbc,
        cqts: res.result.cqts,
        ztcs: res.result.ztcs
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  // 权限方法
  formatAuthority: function (){
    let _appList = this.data.appList;
    let ca = app.globalData.authority
    _appList.map(item => {
      item.visible = item.authority.indexOf(ca) !== -1
    })
    this.setData({
      appList: _appList
    })
  },
  // 考勤打卡
  onCheckIn(){
    wx.navigateTo({
      url: './checkIn/checkIn'
    })
  },

  // 跳转
  itemClick: function (event) {
    if (app.globalData.userId == '' || app.globalData.userId == null){
      wx.navigateTo({
        url: '/pages/me/login/login'
      })
    } else {
      if (event.currentTarget.dataset.url){
        wx.navigateTo({
          url: event.currentTarget.dataset.url
        })
      } 
    }
  },
  //头部详情跳转
  infoSitatisis:function () {
    let me = this;
    wx.navigateTo({
      url: './statistics/statistics'
    })
  },

})
