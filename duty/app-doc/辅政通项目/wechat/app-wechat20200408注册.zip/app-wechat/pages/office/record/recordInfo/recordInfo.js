// pages/office/record/recordInfo/recordInfo.js
const app = getApp()
let util = require('../../../../utils/util.js');
let api = require('../../../../utils/api.method.js');
let xapp = require('../../../../utils/request.url.js');
Page({
  data: {
    dataInfo:'',
    infoId:'',
    heatIsshow:false,
    imgSrc:'',
    record:''
  },
  // 图片预览
  previewImg: function (e) {
    var index = e.currentTarget.dataset.index;
    var imgArr = this.data.imgSrc;
    let arr = imgArr.map((item)=>{
      return xapp.url + item
    })
    wx.previewImage({
      current: xapp.url+imgArr[index],     //当前图片地址
      urls: arr,               //所有要预览的图片的地址集合 数组形式
      // success: function (res) { },
      // fail: function (res) { },
      // complete: function (res) { },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let me = this,id = options['id'];
    if(id){
      me.setData({
        infoId:options['id']
      })
    }
    me.eventListInfo();
  },
  eventListInfo: function () {
    let me = this;
    let params = {
      'reportId': this.data.infoId,
    }
    api.getEventListInfo(params, (res) => {
      let dataInfo = res.result.event;
      let me = this;
      let img = res.result.imgs
      if (res.result.event.eventTypeId == 4){
        me.setData({
          heatIsshow:true
        })
      }else{
        me.setData({
          heatIsshow: false
        })
      }
      me.setData({
        dataInfo: dataInfo,
        imgSrc: img,
        record:dataInfo.record == '1' ? '是' : '否'
      })
      
  
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

})