const app = getApp()
let util = require('../../../../utils/util.js');
let api = require('../../../../utils/api.method.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    page: 1,
    hadLastPage: true,
    pageSize: '20',
    isMore: true,
    loadingHidden: true,
    listData: []
  },

  // 详情
  info: function (e) {
    wx.navigateTo({
      url: 'tableInfo/tableInfo?id=' + e.currentTarget.dataset.id
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // 下拉刷新
  onPullDownRefresh: function () {
    // 标题栏显示刷新图标，转圈圈
    wx.showNavigationBarLoading()
    setTimeout(() => {
      // 标题栏隐藏刷新转圈圈图标
      this.onLoad()
      wx.hideNavigationBarLoading()
      wx.stopPullDownRefresh()
    }, 800);
  },

  onLoad: function (options) {
    let me = this;
    me.eventList(1);
    wx.showLoading({ title: '加载中' })
  },
  onReachBottom: function () {
    let me = this;
    if (this.data.isMore) {
      me.eventList()
    } else {
      wx.showModal({
        title: '提示',
        content: "没有更多信息了",
        showCancel: false,
        isMore: true
      })
    }
  },
  eventList: function (page) {
    let userId = app.globalData.userId, me = this;
    app.globalData.authority == 2 ? userId == '' : userId = app.globalData.userId;
    let params = {
      'userId': userId,
      "pageNum": this.data.page,
      "pageSize": this.data.pageSize
    }
    let listDataTem = this.data.listData;
    api.getNormalSelectAll(params, (res) => {
      let dataList = res.result.list;
      // console.log('dataList', dataList)
      if (dataList.length < this.data.pageSize) {
        this.setData({
          listData: [...listDataTem, ...dataList],//合并数组，es6
          isMore: false,
          loadingHidden: true
        })
        wx.hideLoading()
      } else {
        this.setData({
          listData: [...listDataTem, ...dataList],//合并数组
          page: this.data.page + 1,//页数加1
          isMore: true,
          loadingHidden: true
        })
        wx.hideLoading()
        dataList.map((item) => {
          // console.log(item)
          item.siteName = item.siteName == null ? '暂无站点' : item.siteName
        })
      }
    }, () => {
      wx.showToast({ title: "", icon: "" });
    }
    )
  },
})