const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    date: '',
    time: '',
    timer: null,

    currentDate: new Date().getTime(),
    minDate: new Date(2019, 1, 1).getTime(),
    maxDate: new Date(2050, 1, 1).getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    show: false
  },
  onLoad: function () {
    var time = util.formatTime(new Date());
    this.setData({
      date: time.split(' ')[0],
      time: time.split(' ')[1]
    });
  },

  showPopup() {
    this.setData({ show: true });
  },

  onClose() {
    this.setData({ show: false });
  },

  pickerConfirm(event) {
    this.setData({ show: false });
    this.setData({
      currentDate: event.detail
    });
  },

  pickerCancel() {
    this.setData({ show: false });
  }
})