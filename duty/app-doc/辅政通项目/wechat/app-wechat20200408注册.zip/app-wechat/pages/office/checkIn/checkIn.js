// pages/office/checkIn/checkIn.js

const app = getApp()
let api = require('../../../utils/api.method.js');
var util = require('../../../utils/util.js'); 
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: '',
    att: {
      goto: '',
      gooff: ''
    },
    duty: {
      duration: '',
      endTime: '',
      startTime: ''
    },
    date: '',
    time: '',
    timer: null,

    currentDate: new Date().getTime(),
    minDate: new Date(2019, 1, 1).getTime(),
    maxDate: new Date(2050, 1, 1).getTime(),
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      } else if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    show: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    this.setData({
      name: app.globalData.whitelist.truename
    })
    
    this.getAttendance();
    this.data.timer = setInterval(() => {
      var time = util.formatTime(new Date());
      this.setData({
        date: time.split(' ')[0],
        time: time.split(' ')[1]
      });
    }, 1000);
  },

  // 上岗事件
  updateDuty: function (e) {
    let me = this;
    let duty = e.currentTarget.dataset.duty;
    // 进页面自动获取当前位置
    app.location().then(res => {
      let params = {
        "isDuty": duty,
        "lat": res.latitude,
        "lon": res.longitude,
        // "userId": 14
        "userId": app.globalData.userId
      }

      let post = () => {
        api.postUpdateDuty(params, (res) => {
          if (res.resultCode === 200){
            wx.showToast({
              title: duty === 1 ? "上班打卡成功！" : "下班打卡成功！",
              duration: 2000,
              mask: true,
              success: () => {
                me.getAttendance();
              }
            })
          } 
        },
        )
      }

      if (duty == 0 && this.data.time < this.data.duty.endTime){
        wx.showModal({
          title: '下班打卡',
          content: '是否确定提前下班！',
          success: (res) => { 
            if (res.cancel) {
              console.log('取消下班打卡 !')
            } else {
              post() 
            }
          },
        })
        return;
      }
      post();
    })
  },

  //出勤信息
  getAttendance: function() {
    let me = this;
    let params = {
      // "userId": 14,
      'userId': app.globalData.userId,
      "date": this.data.currentDate
    }

    let formatTime = (date) => {
      return date === null ? '' : date.split(' ')[1];
    }

    api.getAttendance(params, (res) => {
      if (res.result.att !== null){
        me.setData({
          att: {
            goto: formatTime(res.result.att.goto),
            gooff: formatTime(res.result.att.gooff)
          }
        })
      }
      if (res.result.duty === null) {
        wx.showModal({
          title: '提示',
          content: '当前没有值班信息，请联系管理员。',
          success: (res) => {
            var pages = getCurrentPages(); //当前页面
            var beforePage = pages[pages.length - 2]; //前一页
            wx.navigateBack({
              success: function () {
                beforePage.onLoad(); // 执行前一个页面的onLoad方法
              }
            });
          },
        })
      }else{
        me.setData({
          duty: {
            duration: res.result.duty.duration,
            endTime: formatTime(res.result.duty.endTime),
            startTime: formatTime(res.result.duty.startTime)
          }
        })
      }
      
    })
  },

  onUnload: function () {
    clearInterval(this.data.timer)
  },

  showPopup() {
    this.setData({ show: true });
  },
  onClose() {
    this.setData({ show: false });
  },
  pickerConfirm(event) {
    this.setData({ show: false });
    this.setData({
      currentDate: event.detail
    });
    this.getAttendance();
  },
  pickerCancel() {
    this.setData({ show: false });
  }

})

