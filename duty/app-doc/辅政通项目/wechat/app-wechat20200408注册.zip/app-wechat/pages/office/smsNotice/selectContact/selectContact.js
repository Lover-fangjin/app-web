const app = getApp()
let util = require('../../../../utils/util.js');
let api = require('../../../../utils/api.method.js');
let xapp = require('../../../../utils/request.url.js');
let totals;
let gItem = {};//判断level当前页面是哪个页面 {level: -1}
let globalData1 = [], //第2页数据['a','b'...]
    globalData2 = [],//第3页数据['a','b'...]
    globalData_1 = [] //第1页数据['a','b'...]
Page({
  data: {
    checked: false,
    result: [],
    itemList: [],
    resultLength: '',
    iconShow: true,
    loadingHidden: true,
    currentCount: '',
    total: 0,
    preTotal: 0,
    curText: '',
    deptId: 0,
    ids:[],
    levels:''
  },
  onUnload: function () {
    let me = this;
    let _levels = app.globalData.levels;
    let _deptId = me.data.deptId;
    let values = Object.values(_levels);
    values.map(item => {
      if (item.deptId === _deptId) {
        delete _levels[item.id];
      }
    })
    let _names = Object.values(_levels).map(item => { return item.name }).join('>');
    console.log('levels name: ', _names)
    me.setData({
      levels: _names
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    let me = this;
    let _deptId = options.deptId;
    let _levels = app.globalData.levels;
    let _names = Object.values(_levels).map(item => { return item.name }).join('>');
    console.log('levels name: ', _names)

    me.setData({
      ids: [],
      deptId: _deptId,
      levels: _names
    })
    // if (_deptId == -2) {
    //   me.bnsSystem();
    // } else {
      let params = {
        'userId': app.globalData.userId,
        'deptId': _deptId
      }
      let _allChoeese = app.globalData.allChoeese;
      api.getSelectDeptByParentId(params, (res) => {

        console.log('getSelectDeptByParentId : ', res)
        if (res.resultCode == 200){
          let resResult = res.result
          let _ids = []
          let _checkeds = [];
          let _itemList = resResult.map(item => {
            _ids.push(item.id.toString());
            console.log("level: ", item.level)
            let _checked = _allChoeese.hasOwnProperty(parseFloat(item.id));
            if (_checked) { _checkeds.push(item.id.toString()) }
            let _nItem = Object.assign({ checked: _checked || item.level >= app.globalData.level ? true : false }, item);
            return _nItem;
          })

          // globleChoose
          let gRes = resResult.map((item) => {
            gItem = item;
            let nItem = {};
            nItem.id = item.id;
            nItem.name = item.name;
            nItem.total = item.total;
            // console.log('item=', item);

            return nItem;
          })
          //level=-1 表示第一层； level=1 表示第二层
          //{'ztman': nItem, 'ztman2': {}}
          app.globalData.globalChoose.push(...gRes);
          me.setData({
            itemList: _itemList,
            resultLength: res.result.length,
            loadingHidden: true,
            ids: _ids,
            result: _checkeds
          })
          wx.hideLoading()
        }
      }, (res) => {
        wx.showToast({ title: "请求失败", icon: "" });
      })
    // }
  },
  // 单选
  onChange(event) {
    let me = this;
    let detail = event.detail;//['1','2'],
    console.log('onChange: ', detail)

    // add hejin
    let _ids = me.data.ids;
    let _itemList = me.data.itemList;
    _ids.map(id => {
      // id在选中列表中，且全局obj不存在key为id，在全局obj增加key为id及value为name的内容
      if (detail.indexOf(id) !== -1 && !app.globalData.allChoeese.hasOwnProperty(id)){
        let _obj = {
          id: id,
          name: _itemList.filter(item => { return item.id == id })[0].name,
          deptId: me.data.deptId,
        }
        app.globalData.allChoeese[id] = _obj;
      }
      if (detail.indexOf(id) === -1 && app.globalData.allChoeese.hasOwnProperty(id)) {
        delete app.globalData.allChoeese[id];
      }
    })
    // updata checked status
    _itemList = _itemList.map(item => {
      item.checked = app.globalData.allChoeese.hasOwnProperty(item.id) || item.level >= app.globalData.level ? true : false;
      return item;
    })
    let _allChoeese = app.globalData.allChoeese;
    console.log('allChoeese: ', _allChoeese)
    console.log('allChoeese: ', Object.keys(_allChoeese))
    console.log('allChoeese: ', Object.values(_allChoeese).map(item => { return item.name}))

    // console.log('_itemList: ', _itemList)

    this.setData({
      result: detail,//[]
      checked: detail.length == me.data.resultLength,
      itemList: _itemList
      // iconShow: me.data.checked
    }, () => {
      // console.log('fangjin-----0000>> ', me.data.result);
      // console.log('fangjin-----gItem>> ', gItem);
      app.globalData.allDate = [];
      if (gItem.level == '1') {
        globalData1 = me.data.result;
      } else if (gItem.level == '2') {
        globalData2 = me.data.result;
      } else if (gItem.level == '-1') {
        globalData_1 = me.data.result;
      }
      me.setData({
        preTotal: me.data.result.length
      })
    });
  },

  // 全选
  onChanges(event) {
    let me = this;

    console.log('checked all: ', event.detail)
    // add hejin
    let _ids = me.data.ids;
    let _itemList = me.data.itemList;
    _ids.map(id => {
      if (event.detail) {
        let _obj = {
          id: id,
          name: _itemList.filter(item => { return item.id == id })[0].name,
          deptId: me.data.deptId,
        }
        app.globalData.allChoeese[id] = _obj;
      }
      if (!event.detail) {
        delete app.globalData.allChoeese[id];
      }
    })
    _itemList = _itemList.map(item => {
      item.checked = event.detail || item.level >= app.globalData.level ? true : false;
      return item;
    })
    let _allChoeese = app.globalData.allChoeese;
    console.log('allChoeese: ', _allChoeese)
    console.log('allChoeese: ', Object.keys(_allChoeese))
    console.log('allChoeese: ', Object.values(_allChoeese).map(item => { return item.name }))

    globalData1 = [];
    globalData2 = [];
    globalData_1 = [];
    //app.globalData.globalChoose 后台返回的数据列表
    let dptId = app.globalData.globalChoose.map(value => {
      return value.id + '';
    })
    app.globalData.allDate.push(...dptId);
     console.log('fangjin------>>> 全选 app.globalData.allDate=',  app.globalData.allDate);
    me.setData({
      checked: !me.data.checked, //bool
      result: !me.data.checked ? dptId : [], //['1', '2']
      iconShow: me.data.checked,
      itemList: _itemList
    });
    // console.log(app.globalData.allDate)
  },
  // 获取组织架构公司 查询所有业务体系接口
  // bnsSystem: function () {
  //   let me = this;
  //   let params = {
  //     'userId': app.globalData.userId,
  //   }
  //   api.getBnsSystem(params, (res) => {
  //     // totals = res.result[0].total;
  //     let resResult = res.result;
  //     let _ids = []
  //     let gRes = resResult.map((item) => {
  //       _ids.push(item.id.toString());
  //       gItem = item;
  //       let nItem = {};
  //       nItem.id = item.id;
  //       nItem.name = item.name;
  //       nItem.total = item.total;
  //       console.log('item=', item);
  //       return nItem;
  //     })
  //     //level=-1 表示第一层； level=1 表示第二层
  //     //{'ztman': nItem, 'ztman2': {}}
  //     app.globalData.globalChoose = [];
  //     app.globalData.allDate = [];
  //     app.globalData.globalChoose.push(...gRes);
  //     me.setData({
  //       itemList: res.result,
  //       resultLength: res.result.length,
  //       loadingHidden: true,
  //       ids: _ids
  //     })

  //     wx.hideLoading()
  //   }, () => {
  //     wx.showToast({ title: "请求失败", icon: "" });
  //   })
  // },
  // 下一级切换
  nextItem: function (e) {
    let me = this;
    let _id = e.currentTarget.dataset.deptid;
    let _names = e.currentTarget.dataset.name;
    app.globalData.levels[e.currentTarget.dataset.deptid] = {
      id: _id,
      name: e.currentTarget.dataset.name,
      deptId: me.data.deptId
    }
    wx.navigateTo({
      url: 'selectContact?deptId=' + _id + '&names=' + _names,
    })
  },
  // 确定
  determine: function () {
    // app.globalData.allDate = [];
    // if (globalData_1.length < 1) {
    //   app.globalData.allDate.push(...globalData1);
    //   app.globalData.allDate.push(...globalData2);
    // } else {
    //   app.globalData.allDate.push(...globalData_1);
    // }
    app.globalData.allDate.push(...globalData_1);
    app.globalData.allDate.push(...globalData1);
    app.globalData.allDate.push(...globalData2);


    // 清理父子关系
    let _allChoeese = app.globalData.allChoeese;
    let keys = Object.keys(_allChoeese)
    let values = Object.values(_allChoeese)
    values.map(item => {
      if (keys.indexOf(item.deptId) !== -1){
        delete _allChoeese[item.id];
      }
    })
    app.globalData.allChoeese = _allChoeese;
    app.globalData.levels = [];
    
    wx.reLaunch({
      url: '../smsNotice'
    })
  }
})