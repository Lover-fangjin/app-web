const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
let xapp = require('../../../utils/request.url.js');
Page({
  data: {
    itemList: [],
  },
  /**
   * 生命周期函数--监听页面加载
   */ 
  onLoad: function (options) {

  },
  // 下一级切换
  nextItem: function (e) {
    let me = this;
    wx.navigateTo({
      url: 'selectContact?deptId=' + e.currentTarget.dataset.deptid + '&names=' + e.currentTarget.dataset.name,
    })
  },
})