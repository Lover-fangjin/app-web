// pages/office/smsNotice/smsNotice.js
const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
let xapp = require('../../../utils/request.url.js');
let choosePeople = ''; //拼接接收人名
Page({
  data: {
    choosePeople:'',
    contents:'',
    deptIds:[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('getCurrentPages: ', getCurrentPages());
    
    let me = this;
    let deptIds= app.unique(app.globalData.allDate);
    app.globalData.globalChoose.map((value,index)=>{
      choosePeople = choosePeople + value.name + ' ';
    })

    // modify hejin
    let _allChoeese = app.globalData.allChoeese;
    let _names = Object.values(_allChoeese).map(item => { return item.name });
    choosePeople = _names.join(', ');

    me.setData({
      deptIds: deptIds,
      choosePeople:choosePeople
    })
    console.log('selected keys: ', Object.keys(_allChoeese))
  },
  // 跳转通讯录
  onClickSelect:function(){
    wx.navigateTo({
      // url: './selectContact/selectContact?num=0&deptId=0'
      url: './selectContact/selectContact?deptId=0'
    })
  },
  // 发送短息
  formSubmit:function(e){
    let me = this;

    // modify hejin
    let _allChoeese = app.globalData.allChoeese;
    let params = {
      'deptIds': Object.keys(_allChoeese),
      'content': '【埃考恩科技】'+e.detail.value.content
    }
    if (me.data.choosePeople == ''){
      wx.showModal({
        title: '提示',
        content: '请选择接收人',
      })
    }else{
      api.getSendSms(params, (res) => {
        if (res.resultCode == 200) {
          wx.showModal({
            title: '提示',
            content: res.resultName,
            showCancel: false,
            success(res) {
              if (res.confirm) {
                me.setData({
                  contents: '',
                  choosePeople: ''
                })
              }
            }
          })
        }
      }, () => {
        wx.showToast({ title: "请求失败", icon: "" });
      })
    }
    
  },
})

