const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    avatar:'',
    tellphone:'',
    fixation:'',
    email:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let me = this;
    if (app.globalData.userId != '' || app.globalData.userId == 'null') {
      let whitelist = app.globalData.whitelist;
      me.setData({
        tellphone: whitelist.mobile,//手机号
        avatar: app.globalData.avatarUrl,//头像
        fixation: whitelist.ext2,//固话
        email: whitelist.email,//邮箱
      })
    } 
  },
})