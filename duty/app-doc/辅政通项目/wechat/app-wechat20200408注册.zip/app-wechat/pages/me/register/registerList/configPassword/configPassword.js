const app = getApp()
let util = require('../../../../../utils/util.js');
let api = require('../../../../../utils/api.method.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    usernames: '',
    oldPass: '',
    newPass: '',
    agnNewPass: '',
    messageJson:{}
  },
  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
    let me = this;
    me.setData({
      usernames: app.globalData.whitelist.username
    })
    wx.getStorage({
      key: 'messageJson',
      success: function (res) {
        me.setData({
          messageJson: res.data
        })
      }
    })
  },
  onReady:function(){
    let me = this;
    me.setData({
      usernames: me.data.messageJson.username
    })
  },
  // getChangePw
  formSubmit: function (e) {
    let me = this;
    let usermsg = e.detail.value
    if (usermsg.npw != usermsg.agnNewPass) {
      wx.showModal({
        title: '提示',
        content: "两次密码输入不一致"
      })
    } else if (usermsg.npw.length < 8) {
      wx.showModal({
        title: '提示',
        content: "密码必须8-16位数字"
      })
    }
    else {
      let prams = me.data.messageJson
      prams['password'] = usermsg.agnNewPass;
      api.getAddUser(
        prams,
        function (res) {
          var _data = res.result;
          console.log(res)
          wx.showModal({
            title: '提示',
            content: res.result
          })
          if (res.resultCode == '200') {
            var pages = getCurrentPages(); //当前页面
            var beforePage = pages[app.globalData.login]; //前一页
            wx.navigateBack({
              delta: pages.length - app.globalData.login - 1,
              success: function () {
                beforePage.onLoad(); // 执行前一个页面的onLoad方法
              }
            });
          }
        },
        function () {
          wx.showToast({ title: "请求失败", icon: "none" });
        }
      )
    }

  },
})