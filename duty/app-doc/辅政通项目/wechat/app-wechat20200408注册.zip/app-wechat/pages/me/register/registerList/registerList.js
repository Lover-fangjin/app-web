//获取应用实例
const app = getApp()
let util = require('../../../../utils/util.js');
let api = require('../../../../utils/api.method.js');
let xapp = require('../../../../utils/request.url.js');
import Notify from 'vant-weapp/notify/notify';
var nation = require('../../../../data/nationJson.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    haracterArray: [],//业务角色数组
    haracterIndex: '0',  //业务角色索引
    companyArray:[], //公司名称数组
    companyIndex:'0', //公司名称索引
    teamNameArray:[], //队伍名称数组
    teamNameIndex:'0', //队伍名称
    jobArray:[],//职务
    jobIndex:'0', //职务索引
    hometownValue:'请选择', //籍贯
    army: '',//参军
    sex:'',//性别
    educationArray: ['初中', '高中', '大专','本科','研究生'], 
    educationIndex:'0',
    quyuIndex:0 ,//行政区域
    quyuArray:[] ,//行政区域
    nationArray:[], //民族
    nationIndex:0,
    nationName:'',
    height:'' //身高
  },
  onLoad: function (options) {
    let me = this;
    me.quyuList(); //行政区域
    me.setData({
      nationArray: nation.dataList.data,
      username:options.phone
    })
  },
  // 所在区域列表
  quyuList:function(){
    let me = this;
    let params={}
    api.getAdivision(params, (res) => {
      me.setData({
        quyuArray: res.result
      })
    }, () => {
      wx.showToast({ title: res.result, icon: "" });
    })
  },
  quyuChange: function (e) {
    let me = this;
    let id = me.data.quyuArray[e.detail.value].id;
    me.setData({
      quyuIndex: e.detail.value,
      quanxuanId: id  //业务角色id
    })
    console.log(id)
    // 业务角色列表请求
    let params={
      adivisionId: id
    }
    api.getBnsSystems(params, (res) => {
      me.setData({
        haracterArray: res.result,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  //业务角色 change事件
  ywHaracterChange: function (e) {
    let me = this;
    let id = me.data.haracterArray[e.detail.value].id;
    this.setData({
      haracterIndex: e.detail.value,
      haracterid:id  //业务角色id
    })
    // 获取公司接口请求
    let params = {
      bnsSystemId: id
    }
    api.getCompany(params, (res) => {
      me.setData({
        companyArray: res.result,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  //公司名称 change事件
  companyNameChange: function (e) {
    let me = this;
    let id = me.data.companyArray[e.detail.value].id;
    this.setData({
      companyIndex: e.detail.value,
      companyid: id
    })
    // 获取队伍
    let params = {
      companyId: id
    }
    api.getCompanyTeam(params, (res) => {
      me.setData({
        teamNameArray: res.result,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
    // 获取职务
    let param = {
      bnsSystemId: me.data.haracterid, //角色
      adivisionId: me.data.quanxuanId,//区域
      companyId: id //公司
    }
    api.getJobTitle(param, (res) => {
      console.log(res)
      me.setData({
        jobArray: res.result,
      })
    }, () => {
      wx.showToast({ title: "请求失败", icon: "" });
    })
  },
  //队伍名称 change事件
  teamNameChange: function (e) {
    let me = this;
    let id = me.data.teamNameArray[e.detail.value].id;
    this.setData({
      teamNameIndex: e.detail.value,
      teamId: id  //队伍名称id
    })
  },

  //职务 change事件
  jobChange: function (e) {
    let me = this;
    let id = me.data.jobArray[e.detail.value].id;
    this.setData({
      jobIndex: e.detail.value,
      jobId: id  //职务id
    })
  },
  //籍贯
  hometownChange: function (e) {
    this.setData({
      hometownValue: e.detail.value[0] + "" + e.detail.value[1] + "" + e.detail.value[2], //拼的字符串传后台
    })
  },
  //  性别
  sexChange(event){
    this.setData({
      sex: event.detail
    });
  },
  // 出入记录单选框
  armyChange(event) {
    this.setData({
      army: event.detail
    });
  },
  //学历
  educationChange: function (e) {
    let me = this;
    this.setData({
      educationIndex: e.detail.value
    })
  },
  //民族changge 
  nationChange:function(e){
    let me = this;
    let names = me.data.nationArray[e.detail.value].name;
    this.setData({
      nationName: names,
      nationIndex:e.detail.value
    })
  },
  // 提交
  formSubmit: function (e) {
    let me = this;
    let messageJson={}
    messageJson=e.detail.value;
    messageJson['ssex'] = me.data.sex;
    messageJson['exServiceman'] = me.data.army;
    messageJson['adivisionId'] = me.data.quanxuanId;
    messageJson['businessId'] = me.data.haracterid;
    messageJson['companyId'] = me.data.companyid;
    messageJson['deptId'] = me.data.teamId;
    messageJson['postId'] = me.data.jobId;
    messageJson['nativePlace'] = me.data.hometownValue;
    messageJson['username'] = me.data.username; 
    messageJson['nation'] = me.data.nationName;  
    if (e.detail.value.truename == null){
      Notify({ type: 'warning', 'message': '姓名不能为空', duration: 1500 });
    } else if (e.detail.value.ssex == ''){
      Notify({ type: 'warning', 'message': '性别不能为空', duration: 1500 });
    } else if (e.detail.value.adivisionId == undefined) {
      Notify({ type: 'warning', 'message': '请选择所在区域', duration: 1500 });
    } else if (e.detail.value.businessId == undefined) {
      Notify({ type: 'warning', 'message': '请选择业务角色', duration: 1500 });
    } else if (e.detail.value.companyId == undefined) {
      Notify({ type: 'warning', 'message': '请选择公司名称', duration: 1500 });
    } else if (e.detail.value.deptId == undefined) {
      Notify({ type: 'warning', 'message': '请选择队伍名称', duration: 1500 });
    } else if (e.detail.value.postId == undefined) {
      Notify({ type: 'warning', 'message': '请选择职务', duration: 1500 });
    }else{
      wx.setStorage({
        key: 'messageJson',
        data: messageJson,
        success: function (res) {
          wx.navigateTo({
            url: './configPassword/configPassword'
          })
        }
      })
    }
  },
})