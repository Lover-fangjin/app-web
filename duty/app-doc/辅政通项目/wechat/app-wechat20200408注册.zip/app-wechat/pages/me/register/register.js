// pages/me/register/register.js
const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');
import Notify from '../../../miniprogram_npm/vant-weapp/notify/notify';
Page({
  data: {
    hidden: true,
    btnValue: '',
    btnDisabled: false,
    code: '',
    second: 60,
    phone:''
  },
  onLoad: function (options) {
    let me = this;
  },
  onReady: function () {

  },
  // 手机号
  bindPhoneInput(e) {
    var val = e.detail;
    this.setData({
      phone: val
    })
    if(val.length== 11){
      this.setData({
        hidden: false,
        btnValue: '获取验证码'
      })
    }else {
      this.setData({
        hidden: true,
        btnValue:''
      })
    }
  },
  //验证码输入
  bindsmsInput(e) {
    this.setData({
      code: e.detail
    })
  },
  //获取短信验证码
  getCode(e) {
    var me = this;
    let params = {
      phone: me.data.phone
    }
    api.getSmsCaptcha(params, (res) => {
       
    }, () => {
      wx.showToast({ title: res.result, icon: "" });
    })
     me.timer();  
  },
  // 获取验证码定时器
  timer: function () {
    let promise = new Promise((resolve, reject) => {
    let setTimer = setInterval(() => {
        var second = this.data.second - 1;
        this.setData({
          second: second,
          btnValue: second + '秒',
          btnDisabled: true
        })
        if (this.data.second <= 0) {
          this.setData({
            second: 60,
            btnValue: '获取验证码',
            btnDisabled: false
          })
          resolve(setTimer)
        }
      }
      , 1000)
    })
    promise.then((setTimer) => {
      clearInterval(setTimer)
    })
  },
  // 协议跳转
  protocol:function(){
    wx.navigateTo({
      url: './protocol/protocol',
    })
  },
  //注册
  formSubmit:function(){
    let me = this;
    let regObjece={
      phone: me.data.phone,
      verifyCode: me.data.code
    }
    api.getVerificationCode(regObjece, (res) => {
      if (res.result == '0'){
        wx.navigateTo({
          url: './registerList/registerList?phone=' + me.data.phone,
        })
      }else{
        Notify({ type: 'warning', 'message': res.result, duration: 1500 });
      }
    }, () => {
      wx.showToast({ title:'请求失败', icon: "" });
    })
   
  }
  
})