const app = getApp()
let util = require('../../../../utils/util.js');
let api = require('../../../../utils/api.method.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    usernames:'',
    oldPass:'',
    newPass:'',
    agnNewPass:'',
  },
  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
    let me = this;
    console.log()
    me.setData({
      usernames: app.globalData.whitelist.username
    })
  },

  // getChangePw
  formSubmit:function(e){
    let me = this;
    let usermsg={}
    usermsg= e.detail.value;
    usermsg['username'] = app.globalData.whitelist.username
    if (usermsg.npw != usermsg.agnNewPass){
      wx.showModal({
        title: '提示',
        content: "确认密码与新密码不符"
      })
    } else if (usermsg.npw.length<8){
      wx.showModal({
        title: '提示',
        content: "密码必须8-16位数字"
      })
    }
    else{
       api.getChangePw(
        usermsg,
        function (res) {
          var _data = res.result;
          console.log(res)
          wx.showModal({
            title: '提示',
            content: res.result
          })
          var pages = getCurrentPages(); //当前页面
          var beforePage = pages[pages.length - 2]; //前一页
          if (res.result =='修改成功'){
            wx.navigateBack({
              success: function () {
                beforePage.onLoad(); // 执行前一个页面的onLoad方法
              }
            });
          } 
        },
        function () {
          wx.showToast({ title: "账号或密码错误", icon: "none" });
        }
      )
    }
   
  },
 

})