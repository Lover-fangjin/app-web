// pages/login/login.js
const app = getApp()
let util = require('../../../utils/util.js');
let api = require('../../../utils/api.method.js');

Page({
  data: {
    usermsg:{},
    username: '18514255265',//
    password: '123456', //12345678
    lofinDisabled:false,
    hidden:'true',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    avatarUrl:'/images/logo.png',
    loginShow:'false',
    isLogin:'登录',
    isLoginDisible:'false'
  },
  onLoad: function () {
   let me = this;
    var pages = getCurrentPages(); //当前页面
    app.globalData.before = pages.length - 2;
    app.globalData.login = pages.length - 1;
    // 查看是否授权
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称
          wx.getUserInfo({
            success: function (res) {
              // console.log('授权',res)
              app.globalData.avatarUrl = res.userInfo.avatarUrl;
              me.setData({
                showView: true,
                avatarUrl: app.globalData.avatarUrl,
              })
            }
          })
        }
      }
    })
    console.log('login')
  },
  bindGetUserInfo(e) {
    let me = this;
    if (e.detail.userInfo.avatarUrl){
      me.setData({
        avatarUrl: e.detail.userInfo.avatarUrl,
        showView:true
      })
    }
  },
  // 注册
  register:function(){
    wx.navigateTo({
      url: '../register/register'
    })
  },
  loginSubmit: function (e) {
    let me = this;
    me.usermsg = e.detail.value;
    // console.log('me.usermsg', me.usermsg)
    if (me.usermsg.username==null) {
      wx.showModal({
        title: '提示',
        content: "请输入您的账号"
      })
    } else if (me.usermsg.password==null) {
      wx.showModal({
        title: '提示',
        content: "请输入您的密码"
      })
    }else{
      api.wxLogin(
        me.usermsg,
        function (res) {
          var _data = res.result; 
          app.globalData.userId = res.result.userId;
          app.globalData.mobile = res.result.mobile; 
          app.globalData.isDuty = res.result.isDuty;  //上岗、离岗字段
          app.globalData.authority = res.result.roleId;  //权限字段 1 超级管理员  2.政府领导  3.企业领导 4.普通用户  
          app.globalData.whitelist = res.result;  //登录成功保存白名单信息
          var pages = getCurrentPages(); //当前页面
          var beforePage = pages[app.globalData.before]; //前一页
          wx.navigateBack({
            delta: pages.length - app.globalData.before - 1,
            success: function () {
              beforePage.onLoad(); // 执行前一个页面的onLoad方法
            }
          });
          me.setData({
            isLogin:'已登录',
            lofinDisabled:true
          })
        },
        function () {
          wx.showToast({ title: "账号或密码错误", icon: "none" });
        }
      )
    }
  },
})
