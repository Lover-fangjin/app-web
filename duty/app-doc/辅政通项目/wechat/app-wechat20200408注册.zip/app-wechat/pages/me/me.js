// pages/statistics/statistics.js
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    username:'', //用户名
    avatar:'/images/touxiang.png',//头像
    department:'',//部门
    number:'',//编号
    tellphone:'' ,//手机号
    fixation:'', //固化
    mail:'' ,//邮箱
    messInfo:'',
    truename:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // let me = this;
    // if (app.globalData.userId != '' || app.globalData.userId == 'null') {
    //   let whitelist = app.globalData.whitelist;
    //   me.setData({
    //     username: whitelist.username, //用户名
    //     avatar: app.globalData.avatarUrl,//头像
    //     department: whitelist.deptName,//部门
    //     number: whitelist.ext2,//编号
    //     tellphone: whitelist.mobile,//手机号
    //     fixation: '', //固化
    //     mail: whitelist.email,//邮箱
    //     truename: whitelist.truename, //姓名
    //     messInfo:true,
    //   })
    // } else {
    //   wx.showModal({
    //     title: '提示',
    //     content: '为了完整体验，请您登录',
    //     success(res) {
    //       if (res.confirm) {
    //         wx.navigateTo({
    //           url: './login/login'
    //         })
    //       } else if (res.cancel) {
    //       }
    //     }
    //   })
    // }
  },
  // 设置页面跳转
  tapConfig:function(){
    wx.navigateTo({
      url: '/pages/me/config/config'
    })
  },

  //每次页面刷新时显示
  onShow:function(){
    let me = this;
    if (app.globalData.userId != '' || app.globalData.userId == 'null') {
      let whitelist = app.globalData.whitelist;
      me.setData({
        username: whitelist.username, //用户名
        avatar: app.globalData.avatarUrl,//头像
        department: whitelist.deptName,//部门
        number: whitelist.ext2,//编号
        tellphone: whitelist.mobile,//手机号
        fixation: '', //固化
        mail: whitelist.email,//邮箱
        truename: whitelist.truename, //姓名
        messInfo: true,
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '为了完整体验，请您登录',
        success(res) {
          if (res.confirm) {
            wx.navigateTo({
              url: './login/login'
            })
          } else if (res.cancel) {
          }
        }
      })
    }
  }
})