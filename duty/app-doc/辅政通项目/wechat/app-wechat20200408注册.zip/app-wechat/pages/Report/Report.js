//index.js
//获取应用实例
const app = getApp()
let util = require('../../utils/util.js');
let api = require('../../utils/api.method.js');
Page({
  data: {
    zdname:'',
    address:'',
    eventType:'',
    address:'',
    detile:'',
    submitDisable:false,
    fileList: [],
    imgIdList:[],
    formatLocation:{},//经纬度容器
    addr:'',
    show: false,
    zdNameArray: ['', '礼贤镇农建科', '恒信建业资产管理有限公司', '清源街道社会化', '市政养护队', '西红门城管', '西红门综治'],
    eventTypeArray: ['', '火灾', '袭警', '闯岗', '盗窃', '发热'],
    zdIndex: 1,
    TypeIndex:1,
    submitDisable:false,
  },
  // 站点名称
  bindPickerZdChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      zdIndex: e.detail.value
    })
  },
// 事件类型
  bindPickerTypeChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      TypeIndex: e.detail.value
    })
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    let me = this;
    app.getLocation();
    wx.hideHomeButton() //取消左上角返回首页方法
  },
  onReady: function (e) {
  },
  // 上传
  afterRead(event) {
    const { file } = event.detail;
    let me = this;
    // 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
    wx.uploadFile({
      // url: 'http://192.168.10.81:8080/upload/singlefile', 
      url: 'http://fztsp.bjxingtaikeji.com/duty_manager_api/upload/singlefile', 
      filePath: file.path,
      name: 'file',
      formData: { user: 'test' },
      success(res) {
        // 上传完成需要更新 fileList
        const { fileList = [] } = me.data,{ imgIdList = [] } = me.data;
        let imgData = JSON.parse(res.data).result
          , imgUrl = `http://fztsp.bjxingtaikeji.com/duty_manager_api${imgData.filePath}`
        ,imgId = imgData.attachmentId;
        console.log('imgData.filePath', imgData.filePath)
        fileList.push({ ...file, url: imgUrl });
        me.data.imgIdList.push(imgId)
        me.setData({ fileList, imgId});
      }
    });
  },
  //上传图片删除
  deleteImg:function(e){
    console.log(e)
    let index = e.detail.index, imgIdList = this.data.imgIdList;
    imgIdList.splice(index,1);
    this.setData({
      imgIdList: imgIdList
    })
  },
  // 地址选择
  chooseMap:function(){
    let that = this;
    wx.chooseLocation({
      success(res) {
        console.log(res)
        that.setData({
          // hasLocation: true,
          // location: formatLocation(res.longitude, res.latitude),
          address: res.address
        })
      },
      fail: function () {
        wx.getSetting({
          success: function (res) {
            var statu = res.authSetting;
            if (!statu['scope.userLocation']) {
              wx.showModal({
                title: '是否授权当前位置',
                content: '需要获取您的地理位置，请确认授权，否则地图功能将无法使用',
                success: function (tip) {
                  if (tip.confirm) {
                    wx.openSetting({
                      success: function (data) {
                        if (data.authSetting["scope.userLocation"] === true) {
                          wx.showToast({
                            title: '授权成功',
                            icon: 'success',
                            duration: 1000
                          })
                          //授权成功之后，再调用chooseLocation选择地方
                          wx.chooseLocation({
                            success: function (res) {
                              obj.setData({
                                addr: res.address
                              })
                            },
                          })
                        } else {
                          wx.showToast({
                            title: '授权失败',
                            icon: 'success',
                            duration: 1000
                          })
                        }
                      }
                    })
                  }
                }
              })
            }
          },
          fail: function (res) {
            wx.showToast({
              title: '调用授权窗口失败',
              icon: 'success',
              duration: 1000
            })
          }
        })
      }
    })
  },
  // 提交
  formSubmit: function (e) {
    var _this = this;
    let eventdata ={};
    eventdata = e.detail.value;
    eventdata['tel'] = app.globalData.mobile
    eventdata['userId'] = app.globalData.userId
    eventdata['ext2'] = app.globalData.longitude
    eventdata['ext3'] = app.globalData.latitude
    let reportData ={
      'eventReport': eventdata,
      'imageIds': _this.data.imgIdList,
      'userId':app.globalData.userId
    }
    // console.log(reportData)
    api.reports(
      reportData,
      function (res) {
        var _data = res.result;
        console.log(res)
        wx.showModal({
          title: '提示',
          content: "上报成功",
          success: function (res) {
            console.log(res)
            if (res.confirm) {
              wx.switchTab({
                url:'/pages/index/index'
              })
              _this.setData({
                address: '',
                detile: '',
                submitDisable: true
              });
            } else if (res.cancel) {
              _this.setData({
                submitDisable: false
              });
              // console.log('用户点击关闭')
            }
          }
        })
        //   wx.hideLoading();
        },
      function () {
        _this.setData({ listArry: [] });
        // wx.hideLoading();
      }
    )
  },
  formReset:function(){
    // console.log('reset')
  }
})
