const xapp = require('./request.url.js');

// 登录
let wxLogin = `${xapp.url}/user/login`
// 上报
let reports = `${xapp.url}/event/eventReport`
// 上传
let upload = `${xapp.url}/upload/singlefile`
// 统计
let updateDuty = `${xapp.url}/user/updateDutyStatus`
//打卡
let attendance = `${xapp.url}/attendance/selectToday`
//事件列表
let eventList = `${xapp.url}/event/selectAll`
// 事件列表详情
let eventListInfo = `${xapp.url}/event/queryById`
// 事件类型 事件数量
let todayTotal = `${xapp.url}/event/queryEventType`
//普通用户上报接口
let normalReport = `${xapp.url}/normal/normalReport`
// 登记人数 
let normalTotal = `${xapp.url}/normal/todayTotal`
// 办公首页最上面统计
let statisticsCount = `${xapp.url}/user/dutyCount`
//修改密码
let changePw = `${xapp.url}/user/changePw`
// 发送短信
let sendSms = `${xapp.url}/user/sendSms`
// 业务体系
let bnsSystem = `${xapp.url}/bnsSystem/selectAll`
// 大队
let selectDeptByBnsId = `${xapp.url}/bnsSystem/selectDeptByBnsId`
// 中队
let selectDeptByParentId = `${xapp.url}/bnsSystem/selectDeptByParentId`
// 普通事件列表
let normalSelectAll = `${xapp.url}/normal/selectAll`
// 普通事件详情
let normalQueryById = `${xapp.url}/normal/queryById`
// 发送短信
let smsCaptcha = `${xapp.url}/user/sms/captcha`
// 验证注册手机验证码
let verificationCode = `${xapp.url}/user/verificationCode`
//行政区域
let adivision = `${xapp.url}/user/register/getAdivision`
//业务角色
let bnsSystems = `${xapp.url}/user/register/getBnsSystem`
//获取公司
let company = `${xapp.url}/user/register/getCompany`
//获取队伍名称
let companyTeam = `${xapp.url}/user/register/getCompanyTeam`
//获取职务
let jobTitle = `${xapp.url}/user/register/getPostiton`
//注册保存信息
let addUser = `${xapp.url}/user/register/addUser`

module.exports = {
  wxLogin,
  reports,
  upload,
  updateDuty,
  attendance,
  eventList,
  eventListInfo,
  todayTotal,
  normalReport,
  normalTotal,
  statisticsCount,
  changePw,
  sendSms,
  bnsSystem,
  selectDeptByBnsId,
  selectDeptByParentId,
  normalSelectAll,
  normalQueryById,
  smsCaptcha,
  verificationCode,
  adivision,
  bnsSystems,
  company,
  companyTeam,
  jobTitle,
  addUser
}