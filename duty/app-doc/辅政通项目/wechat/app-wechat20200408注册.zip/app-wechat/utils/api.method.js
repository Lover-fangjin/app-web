const api = require('./request.js')
const url = require('./api.config.js')

function wxLogin(param, sFun) { api.requestApi(url.wxLogin, "POST", param, "", sFun, function () {}, function () {}) }

function reports(param, sFun) { api.requestApi(url.reports, "POST", param, "", sFun, function () { }, function () { }) }

function upload(param, sFun) { api.requestApi(url.upload, "POST", param, "", sFun, function () { }, function () { }) }

function postUpdateDuty(param, sFun) { api.requestApi(url.updateDuty, "POST", param, "", sFun, function () { }, function () { }) }

function getAttendance(param, sFun) { api.requestApi(url.attendance, "GET", param, "", sFun, function () { }, function () { }) }

function getEventList(param, sFun) { api.requestApi(url.eventList, "GET", param, "", sFun, function () { }, function () { }) }

function getEventListInfo(param, sFun) { api.requestApi(url.eventListInfo, "GET", param, "", sFun, function () { }, function () { }) }

function getTodayTotal(param, sFun) { api.requestApi(url.todayTotal, "GET", param, "", sFun, function () { }, function () { }) }

function getNormalReport(param, sFun) { api.requestApi(url.normalReport, "POST", param, "", sFun, function () { }, function () { }) }

function getnormalTotal(param, sFun) { api.requestApi(url.normalTotal, "GET", param, "", sFun, function () { }, function () { }) }

function getStatisticsCount(param, sFun) { api.requestApi(url.statisticsCount, "GET", param, "", sFun, function () { }, function () { }) }

function getChangePw(param, sFun) { api.requestApi(url.changePw, "POST", param, "", sFun, function () { }, function () { }) }

function getSendSms(param, sFun) { api.requestApi(url.sendSms, "POST", param, "", sFun, function () { }, function () { }) }

function getBnsSystem(param, sFun) { api.requestApi(url.bnsSystem, "GET", param, "", sFun, function () { }, function () { }) }

function getSelectDeptByBnsId(param, sFun) { api.requestApi(url.selectDeptByBnsId, "GET", param, "", sFun, function () { }, function () { }) }

function getSelectDeptByParentId(param, sFun, fFun) { api.requestApi(url.selectDeptByParentId, "GET", param, "", sFun, fFun, function () { }) }

function getNormalSelectAll(param, sFun) { api.requestApi(url.normalSelectAll, "GET", param, "", sFun, function () { }, function () { }) }

function getNormalQueryById(param, sFun) { api.requestApi(url.normalQueryById, "GET", param, "", sFun, function () { }, function () { }) }

function getSmsCaptcha(param, sFun) { api.requestApi(url.smsCaptcha, "GET", param, "", sFun, function () { }, function () { }) }

function getVerificationCode(param, sFun) { api.requestApi(url.verificationCode, "POST", param, "", sFun, function () { }, function () { }) }

function getAdivision(param, sFun) { api.requestApi(url.adivision, "GET", param, "", sFun, function () { }, function () { }) }

function getBnsSystems(param, sFun) { api.requestApi(url.bnsSystems, "GET", param, "", sFun, function () { }, function () { }) }

function getCompany(param, sFun) { api.requestApi(url.company, "GET", param, "", sFun, function () { }, function () { }) }

function getCompanyTeam(param, sFun) { api.requestApi(url.companyTeam, "GET", param, "", sFun, function () { }, function () { }) }

function getJobTitle(param, sFun) { api.requestApi(url.jobTitle, "GET", param, "", sFun, function () { }, function () { }) }

function getAddUser(param, sFun) { api.requestApi(url.addUser, "POST", param, "", sFun, function () { }, function () { }) }


// function getAllProvinceInnList(param, sFun) { api.requestApi(url.getAllProvinceInnList, "GET", param, "", sFun, function () {}, function () {}) }

module.exports = {
  wxLogin,  //登录
  reports, //上报
  upload, //上传
  postUpdateDuty, //统计
  getAttendance, // 考勤打卡
  getEventList, //事件列表
  getEventListInfo, //事件详情
  getTodayTotal,  //事件数量和事件类型
  getNormalReport, //普通上报
  getnormalTotal,  //登记人数接口
  getStatisticsCount, //办公页面 统计接口
  getChangePw, //修改密码
  getSendSms, //发送短信
  getBnsSystem, //业务体系
  getSelectDeptByBnsId,//查大队
  getSelectDeptByParentId,  //中队
  getNormalSelectAll, //事件登记列表
  getNormalQueryById, //时间列表详情接口
  getSmsCaptcha, //注册获取短信验证码
  getVerificationCode ,//验证注册手机验证码
  getAdivision , //行政区域
  getBnsSystems, //获取业务角色
  getCompany, // 获取公司
  getCompanyTeam, //队伍名称
  getJobTitle,//职务
  getAddUser ,//注册保存信息
}