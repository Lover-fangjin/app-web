module.exports = {url: `http://192.168.10.81:8080/` }
// module.exports = { url: `https://fztsp.bjxingtaikeji.com/duty_manager_api`}
// 正式服务器 formal: ``
//测试服务器 formal: ``